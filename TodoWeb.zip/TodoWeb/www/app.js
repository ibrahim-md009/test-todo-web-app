(function () {
  'use strict';

  /* ================= ثوابت ================= */
  var DAY_NAMES = { 1: 'الاثنين', 2: 'الثلاثاء', 3: 'الأربعاء', 4: 'الخميس', 5: 'الجمعة', 6: 'السبت', 7: 'الأحد' };
  var WEEK_ORDER = [6, 7, 1, 2, 3, 4, 5]; // الأسبوع بيبدأ السبت
  var MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  var TYPE_LABELS = { once: 'مرة واحدة', daily: 'يوميًا', weekly: 'أسبوعيًا', custom: 'كل مدة محددة' };
  var UNIT_LABELS = { days: 'أيام', weeks: 'أسابيع', months: 'شهور' };

  var ICON_CHECK = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  var ICON_EDIT = '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16v4z"/></svg>';
  var ICON_TRASH = '<svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>';

  /* ================= التواريخ ================= */
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmt(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parse(s) {
    var p = s.split('-');
    return { y: +p[0], m: +p[1], d: +p[2] };
  }
  function dayNum(s) {
    var p = parse(s);
    return Math.round(Date.UTC(p.y, p.m - 1, p.d) / 86400000);
  }
  function isoDow(s) {
    var p = parse(s);
    var w = new Date(Date.UTC(p.y, p.m - 1, p.d)).getUTCDay();
    return w === 0 ? 7 : w;
  }
  function daysInMonth(y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); }
  function todayStr() { return fmt(new Date()); }

  /* ================= منطق التكرار ================= */
  // هل المهمة مطلوبة في اليوم ده؟
  function isDue(task, date) {
    if (date < task.start) return false;
    switch (task.type) {
      case 'once':
        return task.done.length === 0 || task.done.indexOf(date) !== -1;
      case 'daily':
        return true;
      case 'weekly':
        return task.weekDays.indexOf(isoDow(date)) !== -1;
      case 'custom': {
        var n = Math.max(1, task.interval | 0);
        if (task.unit === 'days') return (dayNum(date) - dayNum(task.start)) % n === 0;
        if (task.unit === 'weeks') return (dayNum(date) - dayNum(task.start)) % (7 * n) === 0;
        // شهور
        var s = parse(task.start), t = parse(date);
        var m = (t.y - s.y) * 12 + (t.m - s.m);
        if (m < 0 || m % n !== 0) return false;
        return t.d === Math.min(s.d, daysInMonth(t.y, t.m));
      }
    }
    return false;
  }

  function phrase(unit, n) {
    var forms = {
      days: ['يوم', 'يومين', 'أيام', 'يومًا'],
      weeks: ['أسبوع', 'أسبوعين', 'أسابيع', 'أسبوعًا'],
      months: ['شهر', 'شهرين', 'أشهر', 'شهرًا']
    }[unit];
    if (n <= 1) return 'كل ' + forms[0];
    if (n === 2) return 'كل ' + forms[1];
    if (n <= 10) return 'كل ' + n + ' ' + forms[2];
    return 'كل ' + n + ' ' + forms[3];
  }

  function describe(task) {
    if (task.type === 'once') return 'مرة واحدة';
    if (task.type === 'daily') return 'كل يوم';
    if (task.type === 'weekly') {
      return 'كل ' + WEEK_ORDER.filter(function (d) { return task.weekDays.indexOf(d) !== -1; })
        .map(function (d) { return DAY_NAMES[d]; }).join('، ');
    }
    return phrase(task.unit, task.interval);
  }

  window.TodoLogic = { isDue: isDue, describe: describe, fmt: fmt };

  /* ================= التخزين ================= */
  function load(key) {
    try {
      var raw = localStorage.getItem(key);
      var v = raw ? JSON.parse(raw) : [];
      return Array.isArray(v) ? v : [];
    } catch (e) { return []; }
  }
  function persist() {
    try {
      localStorage.setItem('todo.tasks', JSON.stringify(tasks));
      localStorage.setItem('todo.cats', JSON.stringify(cats));
    } catch (e) { /* التخزين مش متاح */ }
  }

  var tasks = load('todo.tasks');
  var cats = load('todo.cats');
  var ui = { tab: 'today', filter: null };

  function catById(id) {
    for (var i = 0; i < cats.length; i++) if (cats[i].id === id) return cats[i];
    return null;
  }
  function taskById(id) {
    for (var i = 0; i < tasks.length; i++) if (tasks[i].id === id) return tasks[i];
    return null;
  }

  /* ================= أدوات ================= */
  function $(sel) { return document.querySelector(sel); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function metaLine(task) {
    var parts = [describe(task)];
    var c = task.cat ? catById(task.cat) : null;
    if (c) parts.push(c.name);
    return esc(parts.join(' • '));
  }

  /* ================= العرض ================= */
  function todayHtml() {
    var t = todayStr(), p = parse(t);
    var list = tasks.filter(function (x) {
      return (ui.filter === null || x.cat === ui.filter) && isDue(x, t);
    });
    var done = list.filter(function (x) { return x.done.indexOf(t) !== -1; }).length;

    var h = '<div class="date">' + DAY_NAMES[isoDow(t)] + ' ' + p.d + ' ' + MONTHS[p.m - 1] + '</div>';

    if (ui.filter !== null) {
      var c = catById(ui.filter);
      h += '<button class="chip on filter" data-action="clear-filter">التصنيف: ' + esc(c ? c.name : '') + ' ✕</button>';
    }

    if (!list.length) {
      h += '<div class="empty">' + (ui.filter !== null
        ? 'مفيش مهام النهاردة في التصنيف ده.'
        : 'مفيش مهام النهاردة.<br>اضغط + لإضافة مهمة جديدة.') + '</div>';
      return h;
    }

    var pct = Math.round(done * 100 / list.length);
    h += '<div class="sub">' + (done === list.length ? 'خلصت كل مهام النهاردة 🎉' : 'تم ' + done + ' من ' + list.length) + '</div>';
    h += '<div class="progress"><div class="bar" style="width:' + pct + '%"></div></div>';
    h += '<ul class="list">' + list.map(function (x) {
      var isDone = x.done.indexOf(t) !== -1;
      return '<li class="card tap task' + (isDone ? ' done' : '') + '" data-action="toggle" data-id="' + x.id + '">' +
        '<span class="check">' + ICON_CHECK + '</span>' +
        '<div class="grow"><div class="title">' + esc(x.title) + '</div><div class="meta">' + metaLine(x) + '</div></div></li>';
    }).join('') + '</ul>';
    return h;
  }

  function catsHtml() {
    var t = todayStr();
    function counts(arr) {
      var due = arr.filter(function (x) { return isDue(x, t); }).length;
      return arr.length + ' مهمة • ' + due + ' النهاردة';
    }
    var h = '<div class="date">التصنيفات</div><div class="sub">اضغط على تصنيف لعرض مهامه</div><ul class="list" style="margin-top:14px">';
    h += '<li class="card tap" data-action="open-cat" data-id="0"><div class="grow"><div class="title">كل المهام</div><div class="meta">' + counts(tasks) + '</div></div></li>';
    h += cats.map(function (c) {
      var inCat = tasks.filter(function (x) { return x.cat === c.id; });
      return '<li class="card tap" data-action="open-cat" data-id="' + c.id + '">' +
        '<div class="grow"><div class="title">' + esc(c.name) + '</div><div class="meta">' + counts(inCat) + '</div></div>' +
        '<button class="iconbtn" data-action="edit-cat" data-id="' + c.id + '" aria-label="تعديل">' + ICON_EDIT + '</button>' +
        '<button class="iconbtn danger" data-action="del-cat" data-id="' + c.id + '" aria-label="حذف">' + ICON_TRASH + '</button></li>';
    }).join('');
    h += '</ul>';
    if (!cats.length) h += '<div class="empty">لسه ما أضفتش تصنيفات.<br>اضغط + لإضافة تصنيف (مثلًا: شغل، بيت، صحة).</div>';
    return h;
  }

  function allHtml() {
    var h = '<div class="date">كل المهام</div>';
    if (!tasks.length) return h + '<div class="empty">لسه ما أضفتش مهام.<br>اضغط + للبدء.</div>';
    h += '<div class="sub">' + tasks.length + ' مهمة</div><ul class="list" style="margin-top:14px">';
    h += tasks.map(function (x) {
      return '<li class="card">' +
        '<div class="grow"><div class="title">' + esc(x.title) + '</div><div class="meta">' + metaLine(x) + '</div></div>' +
        '<button class="iconbtn" data-action="edit-task" data-id="' + x.id + '" aria-label="تعديل">' + ICON_EDIT + '</button>' +
        '<button class="iconbtn danger" data-action="del-task" data-id="' + x.id + '" aria-label="حذف">' + ICON_TRASH + '</button></li>';
    }).join('') + '</ul>';
    return h;
  }

  function render() {
    var view = $('#view');
    view.innerHTML = ui.tab === 'today' ? todayHtml() : ui.tab === 'cats' ? catsHtml() : allHtml();
    var btns = document.querySelectorAll('.tabs button');
    for (var i = 0; i < btns.length; i++) btns[i].classList.toggle('on', btns[i].getAttribute('data-tab') === ui.tab);
    $('#fab').setAttribute('aria-label', ui.tab === 'cats' ? 'إضافة تصنيف' : 'إضافة مهمة');
  }

  /* ================= النوافذ المنبثقة ================= */
  var modalOpen = false;

  function showModal(html) {
    hideModal(true);
    $('#modal-root').innerHTML = '<div class="backdrop"></div><div class="sheet" role="dialog" aria-modal="true">' + html + '</div>';
    modalOpen = true;
    try { history.pushState({ m: 1 }, ''); } catch (e) { /* ignore */ }
    return $('#modal-root .sheet');
  }

  // silent=true: من غير ما نرجع خطوة في تاريخ المتصفح
  function hideModal(silent) {
    var wasOpen = modalOpen;
    modalOpen = false;
    $('#modal-root').innerHTML = '';
    if (wasOpen && !silent) { try { history.back(); } catch (e) { /* ignore */ } }
  }

  // زرار الرجوع في أندرويد بيقفل النافذة بدل ما يقفل التطبيق
  window.addEventListener('popstate', function () {
    if (modalOpen) { modalOpen = false; $('#modal-root').innerHTML = ''; }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && modalOpen) hideModal(); });
  $('#modal-root').addEventListener('click', function (e) {
    if (e.target.classList.contains('backdrop')) hideModal();
  });

  function confirmBox(title, message, okLabel, onOk) {
    var sheet = showModal('<h2>' + esc(title) + '</h2><p>' + esc(message) + '</p>' +
      '<div class="actions"><button class="btn ghost" data-m="close">إلغاء</button>' +
      '<button class="btn danger" data-m="ok">' + esc(okLabel) + '</button></div>');
    sheet.addEventListener('click', function (e) {
      var el = e.target.closest('[data-m]');
      if (!el) return;
      if (el.getAttribute('data-m') === 'close') hideModal();
      if (el.getAttribute('data-m') === 'ok') { hideModal(); onOk(); }
    });
  }

  /* ---------- نافذة التصنيف ---------- */
  function openCatEditor(cat) {
    var sheet = showModal('<h2>' + (cat ? 'تعديل التصنيف' : 'تصنيف جديد') + '</h2>' +
      '<label class="lbl" for="cat-name">اسم التصنيف</label>' +
      '<input id="cat-name" type="text" maxlength="40" value="' + esc(cat ? cat.name : '') + '" autocomplete="off">' +
      '<div class="actions"><button class="btn ghost" data-m="close">إلغاء</button>' +
      '<button class="btn primary" data-m="save">حفظ</button></div>');
    var input = sheet.querySelector('#cat-name');

    function save() {
      var name = input.value.trim();
      if (!name) { input.focus(); return; }
      if (cat) cat.name = name; else cats.push({ id: Date.now(), name: name });
      persist(); hideModal(); render();
    }
    sheet.addEventListener('click', function (e) {
      var el = e.target.closest('[data-m]');
      if (!el) return;
      if (el.getAttribute('data-m') === 'close') hideModal();
      if (el.getAttribute('data-m') === 'save') save();
    });
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') save(); });
    setTimeout(function () { input.focus(); }, 50);
  }

  /* ---------- نافذة المهمة ---------- */
  function chip(k, v, label, on) {
    return '<button type="button" class="chip' + (on ? ' on' : '') + '" data-m="set" data-k="' + k + '" data-v="' + esc(v) + '">' + esc(label) + '</button>';
  }

  function draftValid(d) {
    if (!d.title.trim()) return false;
    if (d.type === 'weekly') return d.weekDays.length > 0;
    if (d.type === 'custom') return d.interval >= 1;
    return true;
  }

  function editorHtml(d, isNew) {
    var h = '<h2>' + (isNew ? 'مهمة جديدة' : 'تعديل المهمة') + '</h2>' +
      '<label class="lbl" for="t-title">اسم المهمة</label>' +
      '<input id="t-title" type="text" maxlength="120" data-m="title" value="' + esc(d.title) + '" autocomplete="off">';

    if (cats.length) {
      h += '<span class="lbl">التصنيف</span><div class="chips">' + chip('cat', 0, 'بدون', d.cat === 0) +
        cats.map(function (c) { return chip('cat', c.id, c.name, d.cat === c.id); }).join('') + '</div>';
    }

    h += '<span class="lbl">التكرار</span><div class="chips">' +
      Object.keys(TYPE_LABELS).map(function (k) { return chip('type', k, TYPE_LABELS[k], d.type === k); }).join('') + '</div>';

    if (d.type === 'weekly') {
      h += '<span class="lbl">في أنهي أيام؟</span><div class="chips">' +
        WEEK_ORDER.map(function (n) {
          var on = d.weekDays.indexOf(n) !== -1;
          return '<button type="button" class="chip' + (on ? ' on' : '') + '" data-m="day" data-v="' + n + '">' + DAY_NAMES[n] + '</button>';
        }).join('') + '</div>';
    }

    if (d.type === 'custom') {
      h += '<span class="lbl">كل كام؟</span><div class="row"><span>كل</span>' +
        '<input type="number" inputmode="numeric" min="1" max="999" data-m="interval" value="' + (d.interval || '') + '"></div>' +
        '<div class="chips" style="margin-top:10px">' +
        Object.keys(UNIT_LABELS).map(function (k) { return chip('unit', k, UNIT_LABELS[k], d.unit === k); }).join('') + '</div>' +
        '<div class="hint">العدّ بيبدأ من يوم إنشاء المهمة.</div>';
    }

    h += '<div class="actions"><button class="btn ghost" data-m="close">إلغاء</button>' +
      '<button class="btn primary" data-m="save"' + (draftValid(d) ? '' : ' disabled') + '>حفظ</button></div>';
    return h;
  }

  function openTaskEditor(task) {
    var isNew = !task;
    var d = task
      ? { id: task.id, title: task.title, type: task.type, weekDays: task.weekDays.slice(), interval: task.interval, unit: task.unit, start: task.start, done: task.done.slice(), cat: task.cat || 0 }
      : { id: Date.now(), title: '', type: 'daily', weekDays: [], interval: 2, unit: 'days', start: todayStr(), done: [], cat: ui.filter || 0 };

    var sheet = showModal(editorHtml(d, isNew));

    function redraw() {
      var st = sheet.scrollTop;
      sheet.innerHTML = editorHtml(d, isNew);
      sheet.scrollTop = st;
    }
    function updateSave() {
      var b = sheet.querySelector('[data-m="save"]');
      if (b) b.disabled = !draftValid(d);
    }
    function save() {
      if (!draftValid(d)) return;
      var out = {
        id: d.id, title: d.title.trim(), type: d.type,
        weekDays: d.type === 'weekly' ? d.weekDays.slice().sort() : [],
        interval: Math.max(1, d.interval | 0), unit: d.unit,
        start: d.start, done: d.done, cat: d.cat
      };
      var existing = taskById(d.id);
      if (existing) tasks[tasks.indexOf(existing)] = out; else tasks.push(out);
      persist(); hideModal(); render();
    }

    sheet.addEventListener('click', function (e) {
      var el = e.target.closest('[data-m]');
      if (!el) return;
      var m = el.getAttribute('data-m');
      if (m === 'set') {
        var k = el.getAttribute('data-k'), v = el.getAttribute('data-v');
        d[k] = k === 'cat' ? Number(v) : v;
        redraw();
      } else if (m === 'day') {
        var n = Number(el.getAttribute('data-v'));
        d.weekDays = d.weekDays.indexOf(n) !== -1 ? d.weekDays.filter(function (x) { return x !== n; }) : d.weekDays.concat(n);
        redraw();
      } else if (m === 'close') {
        hideModal();
      } else if (m === 'save') {
        save();
      }
    });
    sheet.addEventListener('input', function (e) {
      var m = e.target.getAttribute('data-m');
      if (m === 'title') d.title = e.target.value;
      else if (m === 'interval') d.interval = parseInt(e.target.value, 10) || 0;
      updateSave();
    });
    sheet.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && e.target.getAttribute('data-m') === 'title') save();
    });
    if (isNew) setTimeout(function () { var i = sheet.querySelector('#t-title'); if (i) i.focus(); }, 50);
  }

  /* ================= الأحداث ================= */
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-action]');
    if (!el) return;
    var a = el.getAttribute('data-action');
    var id = Number(el.getAttribute('data-id'));

    if (a === 'tab') {
      ui.tab = el.getAttribute('data-tab');
      render();
      window.scrollTo(0, 0);
    } else if (a === 'fab') {
      if (ui.tab === 'cats') openCatEditor(null); else openTaskEditor(null);
    } else if (a === 'toggle') {
      var t = todayStr(), task = taskById(id);
      if (!task) return;
      task.done = task.done.indexOf(t) !== -1 ? task.done.filter(function (x) { return x !== t; }) : task.done.concat(t);
      persist(); render();
    } else if (a === 'clear-filter') {
      ui.filter = null; render();
    } else if (a === 'open-cat') {
      ui.filter = id === 0 ? null : id;
      ui.tab = 'today';
      render();
      window.scrollTo(0, 0);
    } else if (a === 'edit-cat') {
      openCatEditor(catById(id));
    } else if (a === 'del-cat') {
      var c = catById(id);
      if (!c) return;
      confirmBox('حذف التصنيف', 'هيتحذف التصنيف "' + c.name + '"، والمهام اللي فيه هتفضل موجودة بدون تصنيف.', 'حذف', function () {
        cats = cats.filter(function (x) { return x.id !== id; });
        tasks.forEach(function (x) { if (x.cat === id) x.cat = 0; });
        if (ui.filter === id) ui.filter = null;
        persist(); render();
      });
    } else if (a === 'edit-task') {
      openTaskEditor(taskById(id));
    } else if (a === 'del-task') {
      var tk = taskById(id);
      if (!tk) return;
      confirmBox('حذف المهمة', 'هتتحذف "' + tk.title + '" نهائيًا. متأكد؟', 'حذف', function () {
        tasks = tasks.filter(function (x) { return x.id !== id; });
        persist(); render();
      });
    }
  });

  // لو التطبيق رجع للواجهة بعد منتصف الليل نحدّث اليوم
  var shownDay = todayStr();
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && todayStr() !== shownDay) { shownDay = todayStr(); render(); }
  });

  render();
})();
