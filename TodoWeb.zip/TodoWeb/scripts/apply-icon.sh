#!/usr/bin/env bash
# بيحط أيقونة التطبيق جوه مشروع أندرويد اللي Capacitor ولّده.
# بيتشغّل من فولدر المشروع بعد `npx cap add android`.
set -euo pipefail

RES=android/app/src/main/res
SRC=resources/android

mkdir -p "$RES/drawable" "$RES/values" "$RES/mipmap-anydpi-v26"
cp "$SRC/ic_launcher_fg.xml" "$RES/drawable/tw_icon_fg.xml"
cp "$SRC/tw_colors.xml" "$RES/values/tw_colors.xml"
cp "$SRC/adaptive.xml" "$RES/mipmap-anydpi-v26/ic_launcher.xml"
cp "$SRC/adaptive.xml" "$RES/mipmap-anydpi-v26/ic_launcher_round.xml"

for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$RES/mipmap-$d"
  cp "$SRC/mipmap-$d/ic_launcher.png" "$RES/mipmap-$d/ic_launcher.png"
  cp "$SRC/mipmap-$d/ic_launcher_round.png" "$RES/mipmap-$d/ic_launcher_round.png"
done

echo "icon applied"
